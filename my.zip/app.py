from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
import requests
import time
import random
import pandas as pd
import io
from threading import Thread

app = Flask(__name__)

class User:
    def __init__(self, nickname, subscription_end, is_active=True):
        self.nickname = nickname
        self.subscription_end = subscription_end
        self.is_active = is_active

class UserManager:
    def __init__(self):
        self.users = {}
        self.excel_url = "https://docs.google.com/spreadsheets/d/1uVw-x0AlKJ21qo-e0DFlVWpah_cIgTay/edit?usp=sharing&ouid=116411561498747453406&rtpof=true&sd=true"
        self.load_users()

    def load_users(self):
        file_id = self.excel_url.split('/')[5]
        download_url = f"https://docs.google.com/spreadsheets/d/{file_id}/export?format=xlsx"

        try:
            response = requests.get(download_url)
            response.raise_for_status()
            excel_data = io.BytesIO(response.content)
            df = pd.read_excel(excel_data)

            print("Columns in the Excel file:", df.columns.tolist())

            required_columns = ['닉네임', '구독 만료 날짜', '활성여부']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")

            for _, row in df.iterrows():
                nickname = row['닉네임']
                subscription_end = row['구독 만료 날짜']
                is_active = row['활성여부']

                if pd.isna(nickname) or pd.isna(subscription_end) or pd.isna(is_active):
                    print(f"Skipping row with missing data: {row}")
                    continue

                if isinstance(subscription_end, str):
                    try:
                        subscription_end = datetime.strptime(subscription_end, "%Y-%m-%d")
                    except ValueError:
                        print(f"Invalid date format for {nickname}: {subscription_end}")
                        continue
                elif isinstance(subscription_end, datetime):
                    pass
                else:
                    print(f"Invalid date type for {nickname}: {type(subscription_end)}")
                    continue

                self.users[nickname] = User(
                    nickname,
                    subscription_end,
                    is_active.lower() == '활성'
                )

            print(f"Loaded {len(self.users)} users successfully")

        except requests.RequestException as e:
            print(f"Failed to download the Excel file: {e}")
        except pd.errors.EmptyDataError:
            print("The Excel file is empty")
        except Exception as e:
            print(f"An error occurred while loading users: {e}")

    def check_user(self, nickname):
        user = self.users.get(nickname)
        if user:
            if user.is_active and user.subscription_end > datetime.now():
                return True
            else:
                return "구독이 만료되었습니다."
        return False

    def get_user_status(self, user):
        if not user.is_active or user.subscription_end <= datetime.now():
            return '구독 만료'
        else:
            return '활성'

user_manager = UserManager()

def random_sleep():
    time.sleep(random.randint(2, 6))

def naver_login(driver, id, pw):
    driver.get('https://nid.naver.com/nidlogin.login?mode=form')
    random_sleep()
    driver.find_element(By.CSS_SELECTOR, '#id').send_keys(id)
    random_sleep()
    driver.find_element(By.CSS_SELECTOR, '#pw').send_keys(pw)
    random_sleep()
    driver.find_element(By.XPATH, '//*[@id="log.login"]').click()
    time.sleep(30)

def get_buddy_list(start_id):
    url = f'https://m.blog.naver.com/BuddyList.naver?blogId={start_id}'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    return [a.attrs['href'].split('/')[3] for a in soup.find_all("a") if 'href' in a.attrs]

def add_neighbor(driver, blog_id, message):
    driver.get(f'https://m.blog.naver.com/{blog_id}')
    random_sleep()
    neighbor_button_xpath = '//*[@id="root"]/div[4]/div/div[3]/div[1]/button'
    try:
        neighbor_button = driver.find_element(By.XPATH, neighbor_button_xpath)
        if neighbor_button.text == '이웃추가':
            neighbor_button.click()
            random_sleep()
            driver.find_element(By.XPATH, '//*[@id="bothBuddyRadio"]').click()
            message_box = driver.find_element(By.XPATH,
                                              '//*[@id="buddyAddForm"]/fieldset/div/div[2]/div[3]/div/textarea')
            message_box.clear()
            message_box.send_keys(message)
            random_sleep()
            driver.find_element(By.XPATH, '/html/body/ui-view/div[2]/a[2]').click()
            random_sleep()
    except:
        print(f'{blog_id} 블로그 이웃 추가 실패')

def process_task(user_id, user_pw, start_id, custom_message):
    driver = webdriver.Chrome()
    naver_login(driver, user_id, user_pw)
    buddy_list = get_buddy_list(start_id)

    for blog_id in buddy_list:
        print(f'{blog_id}의 블로그 서로이웃 추가 중')
        add_neighbor(driver, blog_id, custom_message)

    driver.quit()
    print("프로세스 완료")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check_user', methods=['POST'])
def check_user():
    nickname = request.form['nickname']
    result = user_manager.check_user(nickname)
    if result is True:
        return jsonify({'status': 'success'})
    else:
        return jsonify({'status': 'error', 'message': result})

@app.route('/start_process', methods=['POST'])
def start_process():
    nickname = request.form['nickname']
    user_id = request.form['user_id']
    user_pw = request.form['user_pw']
    start_id = request.form['start_id']
    custom_message = request.form['custom_message']

    result = user_manager.check_user(nickname)
    if result is True:
        thread = Thread(target=process_task, args=(user_id, user_pw, start_id, custom_message))
        thread.start()
        return jsonify({'status': 'success', 'message': '프로세스가 시작되었습니다.'})
    else:
        return jsonify({'status': 'error', 'message': result})

@app.route('/refresh_data', methods=['POST'])
def refresh_data():
    user_manager.load_users()
    return jsonify({'status': 'success', 'message': '사용자 데이터가 새로고침되었습니다.'})

if __name__ == '__main__':
    app.run(debug=True)